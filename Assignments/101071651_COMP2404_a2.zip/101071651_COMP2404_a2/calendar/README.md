COMP2404 - Assignment 1
Author: Emma Orhun
S: 101071651
06/11/18

Purpose:
A calendar program made to store events with their name, dates, and times in chronological error and print them out

List of files:
* Calendar.cc
* Calendar.h
* Date.cc
* Date.h
* Event.cc
* Event.h
* Time.cc
* Time.h
* View.cc
* View.h
* Control.cc
* Control.h
* List.cc
* List.h
* main.cc
* in.txt

To compile:
Enter command "make" in command line

To launch with text pre-made input:
./cal < in.txt

To launch with user prompts:
./cal

To operate:
Simply follow the instructions given when the program runs.
Do not input a string when it asks for a number.
